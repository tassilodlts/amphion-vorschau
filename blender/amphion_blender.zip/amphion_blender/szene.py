# „One-click scene“: Sonne nach Ort, Datum und Uhrzeit (NOAA-Formeln) mit physikalischem Himmel oder weißes Studio,
# Boden mit Schattenfänger, Kamera aus dem Viewport oder als Vorgabe (Augenhöhe, Zweipunkt mit Shift, Vogelschau, Axonometrie).
import datetime
import math
import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, StringProperty
from bpy_extras.object_utils import world_to_camera_view
from mathutils import Vector
from . import materialien
from .kern import HILFE, bau_grenzen, ecken, eevee_name, eingang, grenzen, modell_objekte, setze

ORTE = {   # Breite, Länge, UTC-Versatz (Normalzeit), Sommerzeit nach EU-Regel
    'MADRID': ('Madrid', 40.4168, -3.7038, 1, True), 'BARCELONA': ('Barcelona', 41.3874, 2.1686, 1, True),
    'LISBON': ('Lisbon', 38.7223, -9.1393, 0, True), 'PARIS': ('Paris', 48.8566, 2.3522, 1, True),
    'MUNICH': ('Munich', 48.1374, 11.5755, 1, True), 'BERLIN': ('Berlin', 52.52, 13.405, 1, True),
    'VIENNA': ('Vienna', 48.2082, 16.3738, 1, True), 'ZURICH': ('Zurich', 47.3769, 8.5417, 1, True),
    'MILAN': ('Milan', 45.4642, 9.19, 1, True), 'LONDON': ('London', 51.5072, -0.1276, 0, True),
    'NEW_YORK': ('New York', 40.7128, -74.006, -5, True), 'LOS_ANGELES': ('Los Angeles', 34.0522, -118.2437, -8, True),
    'VANCOUVER': ('Vancouver', 49.2827, -123.1207, -8, True), 'MEXICO_CITY': ('Mexico City', 19.4326, -99.1332, -6, False),
    'SAO_PAULO': ('São Paulo', -23.5558, -46.6396, -3, False), 'DUBAI': ('Dubai', 25.2048, 55.2708, 4, False),
    'SINGAPORE': ('Singapore', 1.3521, 103.8198, 8, False), 'TOKYO': ('Tokyo', 35.6762, 139.6503, 9, False),
    'SYDNEY': ('Sydney', -33.8688, 151.2093, 10, False),
}


KAMERAS = [
    ('VIEW', 'From viewport', 'Use the current 3D view'),
    ('TWO_POINT', 'Two-point perspective', 'Eye level, vertical lines kept vertical with lens shift'),
    ('EYE', 'Eye level 1.6 m', 'Natural view of a person standing'),
    ('AERIAL', 'Aerial 45°', 'Bird view from above'),
    ('AXO', 'Axonometric', 'Orthographic isometric view')]


def _ort_setzen(self, context):
    if self.ort in ORTE:
        _, self.breite, self.laenge, self.utc, self.sommerzeit = ORTE[self.ort]


def _neu_licht(self, context):
    if context.scene.objects.get('Amphion Sun'):
        licht(context.scene)


def _neu_kamera(self, context):
    if context.scene.objects.get('Amphion Camera') and self.kamera != 'VIEW':
        kamera(context, self.kamera)


class AmphionSzene(bpy.types.PropertyGroup):
    licht_art: EnumProperty(name='Light', default='SUN', update=_neu_licht, items=[
        ('SUN', 'Sun & sky', 'Real sun position and physical sky for the place, date and time'),
        ('STUDIO', 'Studio white', 'Soft even white light, like a model photo')])
    ort: EnumProperty(name='Location', default='MADRID', update=_ort_setzen,
                      items=[(k, v[0], '') for k, v in ORTE.items()] + [('CUSTOM', 'Custom…', 'Enter latitude and longitude')])
    breite: FloatProperty(name='Latitude', default=40.4168, min=-89.9, max=89.9, update=_neu_licht)
    laenge: FloatProperty(name='Longitude', default=-3.7038, min=-180, max=180, update=_neu_licht)
    utc: FloatProperty(name='UTC offset', default=1, min=-12, max=14, description='Standard time, without daylight saving', update=_neu_licht)
    sommerzeit: BoolProperty(name='Daylight saving', default=True, update=_neu_licht)
    monat: IntProperty(name='Month', default=5, min=1, max=12, update=_neu_licht)
    tag: IntProperty(name='Day', default=20, min=1, max=31, update=_neu_licht)
    stunde: FloatProperty(name='Time', default=17.5, min=0, max=24, precision=2,
                          description='Local clock time in hours (17.5 = 17:30)', update=_neu_licht)
    nord: FloatProperty(name='North', default=0, min=-360, max=360, description='Angle of true north from the +Y axis, clockwise (degrees)',
                        update=_neu_licht)
    boden: BoolProperty(name='Ground', default=True, update=_neu_licht)
    schattenfaenger: BoolProperty(name='Shadow catcher (transparent background)', default=False, update=_neu_licht,
                                  description='Cycles: only shadows on the ground, transparent background for Photoshop')
    kamera: EnumProperty(name='Camera', default='TWO_POINT', update=_neu_kamera, items=KAMERAS)
    seite: FloatProperty(name='Camera side', default=40, min=-180, max=180,
                         description='Where the camera stands relative to the sun (degrees). 40 lights the front facade and shades the side',
                         update=_neu_kamera)
    auto_belichtung: BoolProperty(name='Auto exposure', default=True,
                                  description='Measure the brightness with a tiny test render and set the exposure before rendering')
    ki_text: StringProperty(name='Wishes', default='', description='Optional: style, materials, season, people … (English works best)')
    ki_qualitaet: EnumProperty(name='Quality', default='standard', items=[
        ('standard', 'Standard', '0,25 € per image, free images included'), ('alta', 'High', '0,90 € per image, sharper 2K, needs credit')])
    stimmung: EnumProperty(name='Mood', default='DAY', items=[('DAY', 'Day', ''), ('NIGHT', 'Night', '')])


def sonnenstand(breite, laenge, monat, tag, stunde, utc, sommerzeit, jahr=None):
    # Azimut (Grad ab Nord im Uhrzeigersinn) und Höhe (Grad) der Sonne; NOAA General Solar Position
    jahr = jahr or datetime.date.today().year
    tag = min(tag, [31, 29 if jahr % 4 == 0 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][monat - 1])
    d = datetime.date(jahr, monat, tag)
    tz = utc + (1 if sommerzeit and _sommer(d, breite) else 0)
    n = d.timetuple().tm_yday
    g = 2 * math.pi / 365 * (n - 1 + (stunde - tz - 12) / 24)
    eqt = 229.18 * (0.000075 + 0.001868 * math.cos(g) - 0.032077 * math.sin(g) - 0.014615 * math.cos(2 * g) - 0.040849 * math.sin(2 * g))
    dek = (0.006918 - 0.399912 * math.cos(g) + 0.070257 * math.sin(g) - 0.006758 * math.cos(2 * g) + 0.000907 * math.sin(2 * g)
           - 0.002697 * math.cos(3 * g) + 0.00148 * math.sin(3 * g))
    wahre = stunde * 60 + eqt + 4 * laenge - 60 * tz
    ha = math.radians(wahre / 4 - 180)
    phi = math.radians(breite)
    cz = math.sin(phi) * math.sin(dek) + math.cos(phi) * math.cos(dek) * math.cos(ha)
    hoehe = 90 - math.degrees(math.acos(max(-1, min(1, cz))))
    az = math.degrees(math.atan2(math.sin(ha), math.cos(ha) * math.sin(phi) - math.tan(dek) * math.cos(phi))) + 180
    return az % 360, hoehe


def _sommer(d, breite):
    # EU-Regel: letzter Sonntag im März bis letzter Sonntag im Oktober; Südhalbkugel umgekehrt (grob)
    def letzter_sonntag(m):
        x = datetime.date(d.year, m, 31)
        return x - datetime.timedelta(days=(x.weekday() + 1) % 7)
    drin = letzter_sonntag(3) <= d < letzter_sonntag(10)
    return drin if breite >= 0 else not drin


def _hilfsobjekt(name, daten, szene):
    ob = bpy.data.objects.get(name)
    if ob is None or ob.type != ('LIGHT' if isinstance(daten, bpy.types.Light) else 'CAMERA' if isinstance(daten, bpy.types.Camera) else 'MESH'):
        ob = bpy.data.objects.new(name, daten)
    if ob.name not in szene.objects:
        szene.collection.objects.link(ob)
    ob[HILFE] = True
    return ob


def _welt(szene):
    w = bpy.data.worlds.get('Amphion World') or bpy.data.worlds.new('Amphion World')
    w.use_nodes = True
    szene.world = w
    return w


def _himmel_typ(knoten):
    arten = [i.identifier for i in knoten.bl_rna.properties['sky_type'].enum_items]
    for t in ('MULTIPLE_SCATTERING', 'NISHITA', 'HOSEK_WILKIE'):
        if t in arten:
            return t
    return arten[0]


def licht(szene):
    # Welt, Sonne und Boden nach den Einstellungen setzen; auch für die Nacht-Stimmung
    st = szene.amphion
    w = _welt(szene)
    nt = w.node_tree
    nt.nodes.clear()
    aus = nt.nodes.new('ShaderNodeOutputWorld')
    bg = nt.nodes.new('ShaderNodeBackground')
    nt.links.new(bg.outputs[0], aus.inputs[0])
    sonne_d = bpy.data.lights.get('Amphion Sun') or bpy.data.lights.new('Amphion Sun', 'SUN')
    sonne = _hilfsobjekt('Amphion Sun', sonne_d, szene)
    nacht = st.stimmung == 'NIGHT'
    if st.licht_art == 'STUDIO' and not nacht:
        az, hoehe = 215.0, 50.0
        eingang(bg, 'Color', (0.85, 0.86, 0.88, 1))
        eingang(bg, 'Strength', 0.9)
        sonne_d.energy = 2.2
        sonne_d.angle = math.radians(12)
        sonne_d.color = (1.0, 0.98, 0.95)
    else:
        az, hoehe = sonnenstand(st.breite, st.laenge, st.monat, st.tag, st.stunde, st.utc, st.sommerzeit)
        himmel = nt.nodes.new('ShaderNodeTexSky')
        himmel.sky_type = _himmel_typ(himmel)
        setze(himmel, 'sun_disc', False)
        setze(himmel, 'sun_elevation', math.radians(max(hoehe, -6 if nacht else 1.5)))
        setze(himmel, 'sun_rotation', math.radians(az - st.nord))
        setze(himmel, 'altitude', 100)
        setze(himmel, 'air_density', 1.0)
        setze(himmel, 'dust_density', 1.5)
        setze(himmel, 'aerosol_density', 1.5)
        setze(himmel, 'ozone_density', 1.0)
        nt.links.new(himmel.outputs[0], bg.inputs['Color'])
        h = max(hoehe, 0.0)
        if nacht:
            # Blaue Stunde: dunkler Himmel, schwacher kühler Mond, Fenster leuchten
            nt.nodes.remove(himmel)
            eingang(bg, 'Color', (0.018, 0.032, 0.085, 1))
            eingang(bg, 'Strength', 1.0)
            sonne_d.energy = 0.06
            sonne_d.color = (0.62, 0.72, 1.0)
            sonne_d.angle = math.radians(3)
            az, hoehe = az + 140, 35
        else:
            eingang(bg, 'Strength', 0.13)
            # Abends wird die Sonne wärmer und schwächer
            warm = max(0.0, min(1.0, (20 - h) / 18))
            sonne_d.color = (1.0, 0.93 - 0.18 * warm, 0.85 - 0.35 * warm)
            sonne_d.energy = 4.0 * (0.35 + 0.65 * min(1.0, h / 25)) if hoehe > 0 else 0.0
            sonne_d.angle = math.radians(1.2)
    a, e = math.radians(az - st.nord), math.radians(max(hoehe, 2))
    zur_sonne = Vector((math.sin(a) * math.cos(e), math.cos(a) * math.cos(e), math.sin(e)))
    sonne.rotation_mode = 'QUATERNION'
    sonne.rotation_quaternion = zur_sonne.to_track_quat('Z', 'Y')
    setze(sonne_d, 'use_contact_shadow', True)
    setze(sonne_d, 'shadow_cascade_max_distance', 400)
    # Weiche Sonne in EEVEE Next: Strahlen pro Licht
    setze(sonne_d, 'shadow_jitter', True)
    _glas_nacht(1.0 if nacht else 0.0)
    _boden(szene)
    st['sonne_az'] = az - st.nord
    st['sonne_hoehe'] = hoehe
    return az - st.nord, hoehe


def _glas_nacht(staerke):
    for m in bpy.data.materials:
        if m.get('amphion_art') == 'glas' and m.node_tree and 'nacht' in m.node_tree.nodes:
            m.node_tree.nodes['nacht'].outputs[0].default_value = 0.7 * staerke


def _boden(szene):
    st = szene.amphion
    ob = bpy.data.objects.get('Amphion Ground')
    if not st.boden:
        if ob:
            bpy.data.objects.remove(ob)
        szene.render.film_transparent = False
        return
    g = grenzen(modell_objekte(szene))
    lo, hi = g if g else (Vector((-10, -10, 0)), Vector((10, 10, 10)))
    gross = max(300.0, max(hi - lo) * 25)
    mitte = (lo + hi) / 2
    me = bpy.data.meshes.get('Amphion Ground') or bpy.data.meshes.new('Amphion Ground')
    if not len(me.vertices):
        me.from_pydata([(-0.5, -0.5, 0), (0.5, -0.5, 0), (0.5, 0.5, 0), (-0.5, 0.5, 0)], [], [(0, 1, 2, 3)])
    ob = _hilfsobjekt('Amphion Ground', me, szene)
    ob.location = (mitte.x, mitte.y, lo.z - 0.005)
    ob.scale = (gross, gross, 1)
    # Bringt das Modell Gras oder Gelände mit, setzt der Boden es bis zum Horizont fort; sonst heller Platzbelag
    gruen = any(m.get('amphion_art') in ('gras', 'gelaende') for o in modell_objekte(szene) for m in o.data.materials if m)
    art = 'studio' if st.licht_art == 'STUDIO' else ('gras' if gruen else 'boden')
    me.materials.clear()
    me.materials.append(materialien.material(art))
    setze(ob, 'is_shadow_catcher', st.schattenfaenger)
    szene.render.film_transparent = st.schattenfaenger
    ob.hide_render = False


# --- Kamera -------------------------------------------------------------------------------------------------------------
def _kamera_objekt(szene):
    cd = bpy.data.cameras.get('Amphion Camera') or bpy.data.cameras.new('Amphion Camera')
    ob = _hilfsobjekt('Amphion Camera', cd, szene)
    szene.camera = ob
    cd.clip_start = 0.1
    cd.clip_end = 20000
    cd.sensor_width = 36
    cd.sensor_fit = 'AUTO'
    return ob, cd


def _blick(ob, richtung):
    ob.rotation_mode = 'QUATERNION'
    ob.rotation_quaternion = (-richtung).to_track_quat('Z', 'Y')


def _projektion(szene, ob, punkte):
    bpy.context.view_layer.update()
    return [world_to_camera_view(szene, ob, p) for p in punkte]


def _einpassen(szene, ob, cd, punkte, ziel, richtung, rand=0.08, shift=False, hoehe_fix=None):
    # Abstand (oder Ortho-Größe) und Shift iterativ so wählen, dass alle Ecken mit Rand ins Bild passen
    cd.shift_x = cd.shift_y = 0.0
    d = max((p - ziel).length for p in punkte) * 2.2 + 1
    breit = szene.render.resolution_x * szene.render.pixel_aspect_x
    hoch = szene.render.resolution_y * szene.render.pixel_aspect_y
    for _ in range(12):
        if cd.type == 'ORTHO':
            ob.location = ziel - richtung * d
        elif hoehe_fix is not None:
            flach = Vector((richtung.x, richtung.y, 0)).normalized()
            ob.location = Vector((ziel.x, ziel.y, 0)) - flach * d
            ob.location.z = hoehe_fix
            if not shift:
                _blick(ob, (ziel - ob.location).normalized())
        else:
            ob.location = ziel - richtung * d
        pr = _projektion(szene, ob, punkte)
        if min(p.z for p in pr) <= 0.05:
            d *= 1.6
            continue
        xs, ys = [p.x for p in pr], [p.y for p in pr]
        if shift:
            # Zweipunkt: Kamera waagrecht, Bild per Shift auf das Modell schieben (Shift in Einheiten der längeren Bildseite)
            f = hoch / max(breit, hoch)
            cd.shift_y += ((min(ys) + max(ys)) / 2 - 0.5) * f
            fx = breit / max(breit, hoch)
            cd.shift_x += ((min(xs) + max(xs)) / 2 - 0.5) * fx
            pr = _projektion(szene, ob, punkte)
            xs, ys = [p.x for p in pr], [p.y for p in pr]
        spanne = max((max(xs) - min(xs)), (max(ys) - min(ys))) / (1 - 2 * rand)
        if not shift:
            mx, my = (min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2
            spanne = max(spanne, 2 * max(abs(mx - 0.5) + (max(xs) - min(xs)) / 2, abs(my - 0.5) + (max(ys) - min(ys)) / 2) / (1 - 2 * rand))
        if cd.type == 'ORTHO':
            cd.ortho_scale *= spanne
            if abs(spanne - 1) < 0.01:
                break
            continue
        if abs(spanne - 1) < 0.01:
            break
        d *= spanne ** 0.85


def kamera(context, art):
    szene = context.scene
    st = szene.amphion
    objekte = modell_objekte(szene)
    g = bau_grenzen(objekte)
    if not g:
        return None
    lo, hi = g
    alle = grenzen(objekte)
    boden_z = alle[0].z if alle else lo.z
    punkte = ecken(lo, hi)
    ziel = (lo + hi) / 2
    ob, cd = _kamera_objekt(szene)
    sonne_az = st.get('sonne_az', 215.0)
    seite = math.radians(sonne_az + st.seite)
    zur_kamera = Vector((math.sin(seite), math.cos(seite), 0))
    cd.type = 'PERSP'
    if art == 'VIEW' and _aus_viewport(context, ob, cd):
        return ob
    if art in ('VIEW', 'TWO_POINT'):
        cd.lens = 24
        auge = max(lo.z, boden_z) + 1.6
        richtung = -zur_kamera
        _blick(ob, richtung)
        _einpassen(szene, ob, cd, punkte, ziel, richtung, rand=0.1, shift=True, hoehe_fix=auge)
    elif art == 'EYE':
        cd.lens = 24
        auge = max(lo.z, boden_z) + 1.6
        _einpassen(szene, ob, cd, punkte, ziel, -zur_kamera, rand=0.08, hoehe_fix=auge)
    elif art == 'AERIAL':
        cd.lens = 35
        r = (-zur_kamera * math.cos(math.radians(40)) - Vector((0, 0, math.sin(math.radians(40))))).normalized()
        _blick(ob, r)
        _einpassen(szene, ob, cd, punkte, ziel, r, rand=0.08)
    elif art == 'AXO':
        cd.type = 'ORTHO'
        cd.ortho_scale = max(hi - lo) * 2
        e = math.radians(35.264)
        r = (-zur_kamera * math.cos(e) - Vector((0, 0, math.sin(e)))).normalized()
        # Axonometrie unter 45° zu den Achsen: Seite auf das nächste Achsviertel runden
        q = round((math.degrees(seite) - 45) / 90) * 90 + 45
        a = math.radians(q)
        r = (-Vector((math.sin(a), math.cos(a), 0)) * math.cos(e) - Vector((0, 0, math.sin(e)))).normalized()
        _blick(ob, r)
        _einpassen(szene, ob, cd, punkte, ziel, r, rand=0.06)
    ob['amphion_kamera'] = art
    return ob


def _aus_viewport(context, ob, cd):
    # Kamera = aktuelle 3D-Ansicht (Perspektive oder Ortho); False ohne 3D-Fenster (Hintergrundmodus)
    for fenster in (context.window_manager.windows if context.window_manager else []):
        for area in fenster.screen.areas:
            if area.type != 'VIEW_3D':
                continue
            raum = area.spaces.active
            rv = raum.region_3d
            if rv.view_perspective == 'CAMERA':
                return True
            ob.rotation_mode = 'QUATERNION'
            ob.matrix_world = rv.view_matrix.inverted()
            if rv.view_perspective == 'ORTHO':
                cd.type = 'ORTHO'
                cd.ortho_scale = rv.view_distance * 72 / raum.lens
            else:
                cd.lens = raum.lens
            return True
    return False


def einrichten(context):
    # Der eine Knopf: Licht, Boden, Kamera, sinnvolle Render-Grundwerte
    szene = context.scene
    st = szene.amphion
    st.stimmung = 'DAY'
    if not modell_objekte(szene):
        return 'Import a model first'
    az, hoehe = licht(szene)
    kamera(context, st.kamera)
    if szene.render.engine not in ('CYCLES',):
        szene.render.engine = eevee_name(szene)
    from . import rendern
    rendern.farbe(szene)
    return 'Sun %d° high from %s, camera: %s' % (round(hoehe), _himmelsrichtung(az), dict((k[0], k[1]) for k in KAMERAS)[st.kamera])


def _himmelsrichtung(az):
    return ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'][int(((az % 360) + 22.5) // 45) % 8]


class AMPHION_OT_scene(bpy.types.Operator):
    bl_idname = 'amphion.one_click_scene'
    bl_label = 'One-click scene'
    bl_description = 'Set up sun and sky (or studio light), ground and camera for the imported model'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        self.report({'INFO'}, einrichten(context))
        return {'FINISHED'}


class AMPHION_OT_camera(bpy.types.Operator):
    bl_idname = 'amphion.camera'
    bl_label = 'Set camera'
    bl_description = 'Place the Amphion camera'
    bl_options = {'REGISTER', 'UNDO'}
    art: EnumProperty(items=KAMERAS)

    def execute(self, context):
        context.scene.amphion.kamera = self.art
        if self.art == 'VIEW' or not context.scene.objects.get('Amphion Camera'):
            kamera(context, self.art)
        return {'FINISHED'}
