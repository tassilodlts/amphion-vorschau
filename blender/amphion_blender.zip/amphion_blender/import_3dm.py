# Rhino-Import (.3dm) über rhino3dm: Render-Netze der Datei, sonst eigene Zerlegung (ebene Flächen über ihre Kanten,
# gekrümmte über ein UV-Raster), Blockinstanzen aufgelöst, Layer als Sammlungen, Einheiten in Meter.
import glob
import os
import sys
import bpy
from mathutils import Matrix, Vector
from mathutils.geometry import tessellate_polygon
from . import materialien
from .kern import glatt, verschweissen

EINHEIT = {'millimeters': 0.001, 'centimeters': 0.01, 'meters': 1.0, 'kilometers': 1000.0, 'inches': 0.0254, 'feet': 0.3048,
           'yards': 0.9144, 'miles': 1609.344, 'microns': 1e-6, 'decimeters': 0.1}


def rhino3dm_laden():
    # 4.2+: Blender hat das Rad aus wheels/ schon installiert. 3.6 bis 4.1: passendes Rad selbst in einen Ordner entpacken
    try:
        import rhino3dm
        return rhino3dm
    except ImportError:
        pass
    hier = os.path.dirname(__file__)
    tag = 'cp%d%d' % sys.version_info[:2]
    plattform = 'macosx' if sys.platform == 'darwin' else 'win' if sys.platform.startswith('win') else 'linux'
    for rad in glob.glob(os.path.join(hier, 'wheels', 'rhino3dm-*-%s-*.whl' % tag)):
        if plattform not in rad:
            continue
        ziel = os.path.join(bpy.utils.user_resource('SCRIPTS', path='amphion_lib'), tag)
        if not os.path.isdir(os.path.join(ziel, 'rhino3dm')):
            import zipfile
            os.makedirs(ziel, exist_ok=True)
            with zipfile.ZipFile(rad) as z:
                z.extractall(ziel)
        if ziel not in sys.path:
            sys.path.append(ziel)
        try:
            import rhino3dm
            return rhino3dm
        except ImportError:
            return None
    return None


def _matrix(x):
    return Matrix([[x.M00, x.M01, x.M02, x.M03], [x.M10, x.M11, x.M12, x.M13], [x.M20, x.M21, x.M22, x.M23], [x.M30, x.M31, x.M32, x.M33]])


def _netz(r3, m):
    # rhino3dm.Mesh → (Punkte, Flächen); Vierecke mit c == d sind Dreiecke
    v = m.Vertices
    pkt = [(p.X, p.Y, p.Z) for p in (v[i] for i in range(len(v)))]
    fl = []
    f = m.Faces
    for i in range(len(f)):
        a, b, c, d = f[i]
        fl.append((a, b, c) if c == d else (a, b, c, d))
    return pkt, fl


def _kante_punkte(k):
    try:
        if k.IsLinear():
            return [k.PointAtStart, k.PointAtEnd]
    except TypeError:
        pass
    ok, pl = (False, None)
    try:
        res = k.TryGetPolyline()
        ok, pl = (res if isinstance(res, tuple) else (res is not None, res))
    except Exception:
        pass
    if ok and pl is not None:
        try:
            return [pl[i] for i in range(len(pl))]
        except Exception:
            pass
    d = k.Domain
    n = 24
    return [k.PointAt(d.T0 + (d.T1 - d.T0) * i / n) for i in range(n + 1)]


def _ketten(segmente, tol):
    # Kantenstücke zu geschlossenen Schleifen verbinden
    offen = [list(s) for s in segmente]
    schleifen = []
    nah = lambda a, b: (a - b).length < tol
    while offen:
        kette = offen.pop()
        gewachsen = True
        while gewachsen and not nah(kette[0], kette[-1]):
            gewachsen = False
            for i, s in enumerate(offen):
                if nah(kette[-1], s[0]):
                    kette += s[1:]
                elif nah(kette[-1], s[-1]):
                    kette += s[-2::-1]
                elif nah(kette[0], s[-1]):
                    kette = s[:-1] + kette
                elif nah(kette[0], s[0]):
                    kette = s[:0:-1] + kette
                else:
                    continue
                offen.pop(i)
                gewachsen = True
                break
        if len(kette) > 3 and nah(kette[0], kette[-1]):
            schleifen.append(kette[:-1])
    return schleifen


def _brep_zerlegen(r3, brep, tol):
    # Fallback ohne Render-Netz: ebene Flächen aus den Kanten, die in ihrer Ebene liegen; gekrümmte über ein UV-Raster
    pkt, fl = [], []
    kanten = None
    for fi in range(len(brep.Faces)):
        f = brep.Faces[fi]
        m = None
        try:
            m = f.GetMesh(r3.MeshType.Any)
        except Exception:
            pass
        if m is not None and len(m.Faces):
            p2, f2 = _netz(r3, m)
            o = len(pkt)
            pkt += p2
            fl += [tuple(i + o for i in t) for t in f2]
            continue
        du, dv = f.Domain(0), f.Domain(1)
        try:
            eben = f.IsPlanar()
        except TypeError:
            eben = f.IsPlanar(1e-6)
        if eben:
            if kanten is None:
                kanten = [[Vector((p.X, p.Y, p.Z)) for p in _kante_punkte(brep.Edges[i])] for i in range(len(brep.Edges))]
            um, vm = (du.T0 + du.T1) / 2, (dv.T0 + dv.T1) / 2
            o3 = f.PointAt(um, vm)
            n3 = f.NormalAt(um, vm)
            mitte, nrm = Vector((o3.X, o3.Y, o3.Z)), Vector((n3.X, n3.Y, n3.Z)).normalized()
            bb = f.GetBoundingBox()
            lo, hi = Vector((bb.Min.X, bb.Min.Y, bb.Min.Z)), Vector((bb.Max.X, bb.Max.Y, bb.Max.Z))
            rein = lambda q: all(lo[a] - tol <= q[a] <= hi[a] + tol for a in range(3)) and abs((q - mitte).dot(nrm)) < tol
            teile = [k for k in kanten if all(rein(q) for q in k)]
            schleifen = _ketten(teile, tol)
            if schleifen:
                dreiecke = tessellate_polygon(schleifen)
                flach = [q for s in schleifen for q in s]
                o = len(pkt)
                pkt += [tuple(q) for q in flach]
                for a, b, c in dreiecke:
                    na = (flach[b] - flach[a]).cross(flach[c] - flach[a])
                    fl.append((a + o, b + o, c + o) if na.dot(nrm) >= 0 else (a + o, c + o, b + o))
                continue
        nu = max(2, min(48, 8 * f.SpanCount(0) + (16 if not eben else 0)))
        nv = max(2, min(48, 8 * f.SpanCount(1) + (16 if not eben else 0)))
        o = len(pkt)
        for i in range(nu + 1):
            for j in range(nv + 1):
                q = f.PointAt(du.T0 + (du.T1 - du.T0) * i / nu, dv.T0 + (dv.T1 - dv.T0) * j / nv)
                pkt.append((q.X, q.Y, q.Z))
        umk = f.OrientationIsReversed
        for i in range(nu):
            for j in range(nv):
                a = o + i * (nv + 1) + j
                q = (a, a + nv + 1, a + nv + 2, a + 1)
                fl.append(q[::-1] if umk else q)
    return pkt, fl


def _geometrie(r3, geo, tol):
    # Liefert [(Punkte, Flächen)] in Dateikoordinaten
    T = r3.ObjectType
    typ = geo.ObjectType
    try:
        if typ == T.Mesh:
            return [_netz(r3, geo)]
        if typ == T.Brep:
            return [_brep_zerlegen(r3, geo, tol)]
        if typ == T.Extrusion:
            m = geo.GetMesh(r3.MeshType.Any)
            if m is not None and len(m.Faces):
                return [_netz(r3, m)]
            b = geo.ToBrep(True)
            return [_brep_zerlegen(r3, b, tol)] if b else []
        if typ == T.SubD:
            m = r3.Mesh.CreateFromSubDControlNet(geo)
            return [_netz(r3, m)] if m else []
    except Exception as e:   # einzelne kaputte Objekte überspringen, nicht den ganzen Import
        print('Amphion 3dm: Objekt übersprungen', typ, e)
    return []


class Ergebnis:
    def __init__(self):
        self.teile = {}   # Schlüssel → {'name', 'layer', 'pkt', 'fl', 'mat'(Liste je Fläche), 'mats'(Liste)}
        self.uebersprungen = 0
        self.objekte = 0


def lesen(pfad, zusammenfassen=True, versteckte=False):
    r3 = rhino3dm_laden()
    if r3 is None:
        raise RuntimeError('rhino3dm')
    modell = r3.File3dm.Read(pfad)
    if modell is None:
        raise RuntimeError('lesen')
    name = str(modell.Settings.ModelUnitSystem).split('.')[-1].lower()
    skala = EINHEIT.get(name, 0)
    try:
        tol = max(1e-6, float(modell.Settings.ModelAbsoluteTolerance) * 5)
    except Exception:
        tol = 1e-3
    layer = [modell.Layers[i] for i in range(len(modell.Layers))]
    mats = [modell.Materials[i] for i in range(len(modell.Materials))]
    definitionen = {}
    in_def = set()
    for i in range(len(modell.InstanceDefinitions)):
        d = modell.InstanceDefinitions[i]
        ids = [str(x) for x in d.GetObjectIds()]
        definitionen[str(d.Id)] = ids
        in_def.update(ids)
    nach_id = {}
    for i in range(len(modell.Objects)):
        o = modell.Objects[i]
        nach_id[str(o.Attributes.Id)] = o
    erg = Ergebnis()

    def layer_von(attr):
        return layer[attr.LayerIndex] if 0 <= attr.LayerIndex < len(layer) else None

    def material_von(attr, ly):
        quelle = str(attr.MaterialSource).split('.')[-1]
        idx = attr.MaterialIndex if 'Object' in quelle else (ly.RenderMaterialIndex if ly is not None else -1)
        m = mats[idx] if 0 <= idx < len(mats) else None
        lname = ly.FullPath if ly is not None else ''
        art = materialien.erkennen(m.Name if m else '', lname, attr.Name)
        if art:
            return ('art', art)
        if m is not None and m.Name and m.Name.lower() not in ('default', 'standard'):
            c = m.DiffuseColor
            farbe = tuple(materialien.srgb_linear(x) for x in (c[0], c[1], c[2]))
            return ('eigen', m.Name, farbe, float(getattr(m, 'Transparency', 0) or 0))
        return ('art', 'putz')

    def hinzu(schluessel, anzeigename, lpfad, matkey, stuecke, xf):
        t = erg.teile.setdefault(schluessel, {'name': anzeigename, 'layer': lpfad, 'pkt': [], 'fl': [], 'mat': [], 'mats': []})
        if matkey not in t['mats']:
            t['mats'].append(matkey)
        mi = t['mats'].index(matkey)
        for pkt, fl in stuecke:
            o = len(t['pkt'])
            if xf is not None:
                pkt = [tuple(xf @ Vector(p)) for p in pkt]
            t['pkt'] += pkt
            t['fl'] += [tuple(i + o for i in f) for f in fl]
            t['mat'] += [mi] * len(fl)

    def objekt(o, xf, ly_eltern, tiefe):
        attr, geo = o.Attributes, o.Geometry
        ly = layer_von(attr)
        if ly is None or (ly.FullPath or '').lower() == 'default':
            ly = ly_eltern or ly
        if not versteckte and ((ly is not None and not ly.Visible) or not attr.Visible):
            return
        if geo.ObjectType == r3.ObjectType.InstanceReference:
            if tiefe > 8:
                return
            m = _matrix(geo.Xform)
            x2 = xf @ m if xf is not None else m
            for cid in definitionen.get(str(geo.ParentIdefId), []):
                if cid in nach_id:
                    objekt(nach_id[cid], x2, ly, tiefe + 1)
            return
        stuecke = _geometrie(r3, geo, tol)
        if not stuecke:
            erg.uebersprungen += 1
            return
        erg.objekte += 1
        lpfad = ly.FullPath if ly is not None else 'Default'
        schluessel = lpfad if zusammenfassen else str(attr.Id) + str(id(xf))
        anzeigename = lpfad.split('::')[-1] if zusammenfassen else (attr.Name or lpfad.split('::')[-1])
        hinzu(schluessel, anzeigename, lpfad, material_von(attr, ly), stuecke, xf)

    for i in range(len(modell.Objects)):
        o = modell.Objects[i]
        if str(o.Attributes.Id) in in_def:
            continue
        objekt(o, None, None, 0)
    return erg, skala


def bauen(erg, skala, wurzel, zentrieren=False):
    # Ergebnis als Blender-Objekte unter der Sammlung „wurzel“; Layerpfad A::B::C wird zu verschachtelten Sammlungen
    if not erg.teile:
        return [], Vector()
    alle = [p for t in erg.teile.values() for p in t['pkt']]
    xs, ys, zs = zip(*alle)
    lo, hi = Vector((min(xs), min(ys), min(zs))), Vector((max(xs), max(ys), max(zs)))
    versatz = Vector()
    if zentrieren or ((lo + hi) / 2 * skala).length > 10000:   # weit vom Ursprung (Landeskoordinaten): Genauigkeit retten
        versatz = Vector(((lo.x + hi.x) / 2, (lo.y + hi.y) / 2, lo.z))
    sammlungen = {}

    def sammlung(pfad):
        if pfad in sammlungen:
            return sammlungen[pfad]
        teile = pfad.split('::')
        eltern = sammlung('::'.join(teile[:-1])) if len(teile) > 1 else wurzel
        c = bpy.data.collections.new(teile[-1])
        eltern.children.link(c)
        sammlungen[pfad] = c
        return c

    neu = []
    cache = {}
    for t in erg.teile.values():
        if not t['fl']:
            continue
        pkt = [((x - versatz.x) * skala, (y - versatz.y) * skala, (z - versatz.z) * skala) for x, y, z in t['pkt']]
        me = bpy.data.meshes.new(t['name'])
        me.from_pydata(pkt, [], t['fl'])
        if len(me.polygons) == len(t['mat']):
            me.polygons.foreach_set('material_index', t['mat'])
        me.validate(clean_customdata=False)
        for k in t['mats']:
            if k not in cache:
                cache[k] = materialien.material(k[1]) if k[0] == 'art' else materialien.eigenes(k[1], k[2], k[3])
            me.materials.append(cache[k])
        verschweissen(me, 0.0005)
        glatt(me, 30)
        ob = bpy.data.objects.new(t['name'], me)
        sammlung(t['layer']).objects.link(ob)
        neu.append(ob)
    return neu, versatz * skala

