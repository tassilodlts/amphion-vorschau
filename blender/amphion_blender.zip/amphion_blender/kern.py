# Gemeinsame Helfer für Amphion for Blender: Versionsunterschiede (3.6 bis 5.x), Engine-Namen, sichere Zuweisungen, Modellgrenzen.
import os
import sys
import bpy
from mathutils import Vector

PAKET = __package__
HILFE = 'amphion_hilfe'   # Kennzeichen eigener Hilfsobjekte (Sonne, Boden, Kamera), die nicht zum Modell zählen


def version(haupt, neben=0):
    return bpy.app.version >= (haupt, neben, 0)


def setze(obj, attr, wert):
    # Zuweisen, wenn es die Eigenschaft in dieser Blender-Version gibt; sonst still übergehen
    try:
        setattr(obj, attr, wert)
        return True
    except (AttributeError, TypeError, ValueError, KeyError):
        return False


def eingang(knoten, namen, wert):
    # Principled BSDF benennt Eingänge je Version anders („Transmission“ / „Transmission Weight“)
    for n in namen if isinstance(namen, (list, tuple)) else [namen]:
        if n in knoten.inputs:
            try:
                knoten.inputs[n].default_value = wert
                return knoten.inputs[n]
            except (TypeError, ValueError):
                pass
    return None


def eevee_name(szene):
    # 4.2 bis 4.5 heißt EEVEE Next „BLENDER_EEVEE_NEXT“, davor und ab 5.0 „BLENDER_EEVEE“
    alt = szene.render.engine
    for n in ('BLENDER_EEVEE_NEXT', 'BLENDER_EEVEE'):
        try:
            szene.render.engine = n
            szene.render.engine = alt
            return n
        except TypeError:
            continue
    return 'BLENDER_EEVEE'


def einstellungen():
    a = bpy.context.preferences.addons.get(PAKET)
    return a.preferences if a else None


def modell_objekte(szene=None):
    szene = szene or bpy.context.scene
    return [o for o in szene.objects if o.type == 'MESH' and not o.get(HILFE) and o.visible_get()]


def grenzen(objekte):
    # Weltgrenzen aller Objekte (Ecken der Bounding Boxes); None, wenn leer
    lo = Vector((1e18, 1e18, 1e18))
    hi = -lo
    for o in objekte:
        for c in o.bound_box:
            p = o.matrix_world @ Vector(c)
            lo = Vector(map(min, lo, p))
            hi = Vector(map(max, hi, p))
    return (lo, hi) if objekte and lo.x <= hi.x else None


def ecken(lo, hi):
    return [Vector((x, y, z)) for x in (lo.x, hi.x) for y in (lo.y, hi.y) for z in (lo.z, hi.z)]


def bilder_ordner():
    # ~/Pictures/Amphion (Mac, Windows und Linux gleich)
    ordner = os.environ.get('AMPHION_BILDER') or os.path.join(os.path.expanduser('~'), 'Pictures', 'Amphion')
    os.makedirs(ordner, exist_ok=True)
    return ordner


def zeigen(pfad):
    # Datei im Finder/Explorer zeigen; im Hintergrundmodus nichts öffnen
    if bpy.app.background or not pfad:
        return
    import subprocess
    try:
        if sys.platform == 'darwin':
            subprocess.Popen(['open', '-R', pfad] if os.path.isfile(pfad) else ['open', pfad])
        elif sys.platform.startswith('win'):
            subprocess.Popen(['explorer', '/select,', pfad] if os.path.isfile(pfad) else ['explorer', pfad])
        else:
            subprocess.Popen(['xdg-open', os.path.dirname(pfad) if os.path.isfile(pfad) else pfad])
    except OSError:
        pass


def oeffnen(pfad):
    # Datei mit dem Standardprogramm öffnen (Bildbetrachter)
    if bpy.app.background or not pfad:
        return
    import subprocess
    try:
        if sys.platform == 'darwin':
            subprocess.Popen(['open', pfad])
        elif sys.platform.startswith('win'):
            os.startfile(pfad)   # noqa: nur Windows
        else:
            subprocess.Popen(['xdg-open', pfad])
    except OSError:
        pass


def glatt(mesh, winkel_grad=30.0):
    # Kanten über dem Winkel scharf, Rest weich: 4.1+ set_sharp_from_angle, davor Auto Smooth
    import math
    n = len(mesh.polygons)
    if not n:
        return
    mesh.polygons.foreach_set('use_smooth', [True] * n)
    if hasattr(mesh, 'set_sharp_from_angle'):
        mesh.set_sharp_from_angle(angle=math.radians(winkel_grad))
    else:
        setze(mesh, 'use_auto_smooth', True)
        setze(mesh, 'auto_smooth_angle', math.radians(winkel_grad))
    mesh.update()


def verschweissen(mesh, abstand=0.0005):
    # Doppelte Punkte zusammenführen (Rhino-Flächen und OBJ-Gruppen kommen offen an)
    import bmesh
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=abstand)
    bm.to_mesh(mesh)
    bm.free()


LANDSCHAFT = ('gras', 'gelaende', 'wasser', 'boden', 'studio')


def bau_grenzen(objekte):
    # Grenzen nur der Bauten: Flächen mit Gras-, Gelände- und Wassermaterial zählen nicht (sonst wird das Haus auf dem Grundstück winzig)
    import numpy as np
    lo = np.full(3, 1e18)
    hi = np.full(3, -1e18)
    for o in objekte:
        me = o.data
        land = [i for i, m in enumerate(me.materials) if m and m.get('amphion_art') in LANDSCHAFT]
        if len(land) == len(me.materials) and me.materials:
            continue
        if not land:
            g = grenzen([o])
            if g:
                lo, hi = np.minimum(lo, g[0]), np.maximum(hi, g[1])
            continue
        n = len(me.polygons)
        mi = np.empty(n, np.int32)
        me.polygons.foreach_get('material_index', mi)
        tot = np.empty(n, np.int32)
        me.polygons.foreach_get('loop_total', tot)
        vi = np.empty(len(me.loops), np.int32)
        me.loops.foreach_get('vertex_index', vi)
        behalten = np.repeat(~np.isin(mi, land), tot)
        idx = np.unique(vi[behalten])
        if not len(idx):
            continue
        co = np.empty(len(me.vertices) * 3, np.float32)
        me.vertices.foreach_get('co', co)
        co = co.reshape(-1, 3)[idx]
        m = np.array(o.matrix_world)
        w = co @ m[:3, :3].T + m[:3, 3]
        lo, hi = np.minimum(lo, w.min(0)), np.maximum(hi, w.max(0))
    if lo[0] > hi[0]:
        return grenzen(objekte)
    return Vector(lo.tolist()), Vector(hi.tolist())
