# Amphion for Blender: Architekturmodelle importieren (.3dm, .obj, .fbx, .glb, .stl, .ifc) und mit einem Klick schön rendern.
# Erweiterung für Blender 4.2+ (blender_manifest.toml), bl_info hält die Installation als klassisches Add-on in 3.6 bis 4.1 möglich.
# Seite: https://amphion3d.com/blender/ · Quelle: ~/forma/blender/amphion_blender · Test: blender/test_headless.py
bl_info = {
    'name': 'Amphion for Blender',
    'author': 'Amphion 3D',
    'version': (1, 0, 0),
    'blender': (3, 6, 0),
    'location': 'View3D > Sidebar (N) > Amphion',
    'description': 'Import architecture models and render them beautifully in one click',
    'doc_url': 'https://amphion3d.com/blender/',
    'tracker_url': 'mailto:hello@amphion3d.com',
    'category': 'Render',
}

import bpy
from bpy.props import PointerProperty
from . import cloud, druck, importieren, oberflaeche, rendern, szene

KLASSEN = (
    oberflaeche.AmphionEinstellungen, szene.AmphionSzene,
    importieren.AMPHION_OT_import, szene.AMPHION_OT_scene, szene.AMPHION_OT_camera,
    rendern.AMPHION_OT_preset, rendern.AMPHION_OT_format, rendern.AMPHION_OT_render_save, rendern.AMPHION_OT_open_folder,
    cloud.AMPHION_OT_ai_render, cloud.AMPHION_OT_buy_credit, cloud.AMPHION_OT_subscribe, cloud.AMPHION_OT_subscribe_dialog,
    cloud.AMPHION_OT_account, cloud.AMPHION_OT_refresh, druck.AMPHION_OT_print,
    oberflaeche.AMPHION_PT_main, oberflaeche.AMPHION_PT_scene, oberflaeche.AMPHION_PT_render, oberflaeche.AMPHION_PT_ai,
    oberflaeche.AMPHION_PT_print, oberflaeche.AMPHION_PT_account,
)


def _druck_menue(self, context):
    self.layout.operator(druck.AMPHION_OT_print.bl_idname, text='Amphion 3D print (.stl, .3mf, .obj)')


def _start():
    # Konto- und Gratisstand kurz nach dem Start leise abfragen (nur mit erlaubtem Netzzugang)
    if not bpy.app.background:
        cloud.info_laden()
    return None


def register():
    for k in KLASSEN:
        bpy.utils.register_class(k)
    bpy.types.Scene.amphion = PointerProperty(type=szene.AmphionSzene)
    bpy.types.TOPBAR_MT_file_import.append(importieren.menue)
    bpy.types.TOPBAR_MT_file_export.append(_druck_menue)
    bpy.app.timers.register(_start, first_interval=2.0)


def unregister():
    bpy.types.TOPBAR_MT_file_export.remove(_druck_menue)
    bpy.types.TOPBAR_MT_file_import.remove(importieren.menue)
    del bpy.types.Scene.amphion
    for k in reversed(KLASSEN):
        bpy.utils.unregister_class(k)
