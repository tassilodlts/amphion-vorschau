# Verbindung zur Amphion Cloud (cloud/PLUGINS_API.md, cloud/tools.mjs): Abo und Gratisnutzungen (/v1/plugin/*), KI-Rendering
# (/v1/tools/generar, gleiches Format wie „Render view“ im Rhino-Plugin), Guthaben kaufen (/v1/tools/comprar).
# Netzfehler blockieren nie das lokale Rendern: kurze Zeitgrenze, dann weiter mit leisem Hinweis.
import base64
import json
import os
import tempfile
import threading
import time
import urllib.error
import urllib.request
import uuid
import webbrowser
import bpy
from bpy.props import EnumProperty
from .kern import bilder_ordner, einstellungen, oeffnen

PRODUKT = 'blender'
VERSION = '1.0.0'
stand = {'gratis': None, 'abo': None, 'bis': None, 'preis': 400, 'saldo': None, 'ki_gratis': None, 'meldung': '', 'zeit': 0}


class CloudFehler(Exception):
    def __init__(self, code, status=0, daten=None):
        super().__init__(code)
        self.code, self.status, self.daten = code, status, daten or {}


class NetzFehler(Exception):
    pass


def geraet():
    # Zufällige Gerätekennung, einmal erzeugt und in den Einstellungen gespeichert
    p = einstellungen()
    if p is None:
        return 'blender-' + uuid.uuid4().hex
    if not p.geraet:
        p.geraet = 'blender-' + str(uuid.uuid4())
        try:
            bpy.ops.wm.save_userpref()
        except Exception:
            pass
    return p.geraet


def basis():
    p = einstellungen()
    return (os.environ.get('AMPHION_CLOUD') or (p.cloud if p else '') or 'https://cloud.amphion3d.com').rstrip('/')


def online():
    return getattr(bpy.app, 'online_access', True)


def post(pfad, body, zeit=8.0, p=None):
    # p (Einstellungen) wird im Thread vorab übergeben, weil bpy dort nicht sicher ist
    if not online():
        raise NetzFehler('offline')
    p = p if p is not None else _werte()
    body = dict(body)
    body['geraet'] = p['geraet']
    if p['token']:
        body['token'] = p['token']
    kopf = {'Content-Type': 'application/json', 'User-Agent': 'AmphionBlender/' + VERSION}
    if p['lizenz']:
        kopf['Authorization'] = 'Bearer ' + p['lizenz']
    req = urllib.request.Request(p['basis'] + pfad, data=json.dumps(body).encode(), headers=kopf, method='POST')
    try:
        with urllib.request.urlopen(req, timeout=zeit) as r:
            return json.loads(r.read().decode() or '{}')
    except urllib.error.HTTPError as e:
        try:
            d = json.loads(e.read().decode() or '{}')
        except ValueError:
            d = {}
        raise CloudFehler((d.get('error') or {}).get('code') or 'http%d' % e.code, e.code, d.get('error') or {})
    except (urllib.error.URLError, OSError, ValueError) as e:
        raise NetzFehler(str(e))


def _werte():
    p = einstellungen()
    return {'geraet': geraet(), 'token': (p.token if p else '').strip(), 'lizenz': (p.lizenz if p else '').strip(), 'basis': basis()}


def nutzen(produkt=PRODUKT):
    # Vor Render & save und 3D-Druck-Export: (True, Hinweis) weiter; (False, '') = Abo nötig. Netzfehler → weiter (fail open)
    try:
        r = post('/v1/plugin/nutzen', {'produkt': produkt}, zeit=4.0)
    except CloudFehler as e:
        if e.code == 'abo':
            stand['gratis'] = 0
            stand['abo'] = False
            return False, ''
        return True, ''
    except NetzFehler:
        return True, 'Amphion cloud not reachable, continuing offline'
    stand['abo'] = bool(r.get('abo'))
    stand['gratis'] = r.get('gratis')
    if not r.get('abo') and isinstance(r.get('gratis'), int):
        return True, '%d free renders/exports left' % r['gratis']
    return True, ''


def info_laden():
    # Abo- und Gratisstand im Hintergrund holen (Panel zeigt ihn an)
    if not online():
        return
    werte = _werte()

    def lauf():
        try:
            r = post('/v1/plugin/info', {'produkt': PRODUKT}, zeit=6.0, p=werte)
            stand.update(gratis=r.get('gratis'), abo=bool(r.get('abo')), bis=r.get('bis'), preis=r.get('preis') or 400)
        except (CloudFehler, NetzFehler):
            pass
        try:
            r = post('/v1/tools/info', {}, zeit=6.0, p=werte)
            stand.update(saldo=r.get('saldo'), ki_gratis=r.get('gratis'))
        except (CloudFehler, NetzFehler):
            pass
        stand['zeit'] = time.time()
    threading.Thread(target=lauf, daemon=True).start()
    bpy.app.timers.register(_neu_zeichnen, first_interval=3.0)


def _neu_zeichnen():
    for w in bpy.context.window_manager.windows:
        for a in w.screen.areas:
            if a.type == 'VIEW_3D':
                a.tag_redraw()
    return None


# --- KI-Rendering ------------------------------------------------------------------------------------------------------
FEHLERTEXT = {
    'gratis': 'Your free AI renders are used. Buy credit to keep going (0,25 € per image).',
    'saldo': 'Not enough credit for this image. Buy credit to keep going.',
    'pagar': 'High quality needs credit. Buy credit or choose Standard.',
    'pausa': 'The AI service is busy. Please try again in a minute.',
    'rechazo': 'The AI could not turn this image into a rendering. Try another view.',
    'grande': 'The image is too large.',
    'imagen': 'No image to send.',
}


def _eingabebild(context):
    # Letztes gespeichertes Rendering, sonst ein schnelles EEVEE-Bild der Kamera; als JPEG ≤ 1536 px
    from . import rendern
    pfad = rendern.letztes_bild()
    sz = context.scene
    if not pfad:
        if not sz.camera:
            from . import szene
            if szene.einrichten(context) == 'Import a model first':
                return None, 0, 0
        r = sz.render
        alt = (r.engine, r.resolution_percentage, r.filepath, r.image_settings.file_format)
        rendern._eevee(sz, 32)   # schnell: EEVEE reicht als Vorlage für die KI
        r.resolution_percentage = max(10, min(100, int(100 * 1536 / max(r.resolution_x, r.resolution_y))))
        pfad = os.path.join(tempfile.gettempdir(), 'amphion_ki_quelle.png')
        r.image_settings.file_format = 'PNG'
        r.filepath = pfad
        bpy.ops.render.render(write_still=True)
        r.engine, r.resolution_percentage, r.filepath, r.image_settings.file_format = alt
    bild = bpy.data.images.load(pfad, check_existing=False)
    w, h = bild.size
    f = min(1.0, 1536 / max(w, h, 1))
    if f < 1:
        bild.scale(max(1, int(w * f)), max(1, int(h * f)))
    w, h = bild.size
    jpg = os.path.join(tempfile.gettempdir(), 'amphion_ki_%d.jpg' % os.getpid())
    bild.filepath_raw = jpg
    bild.file_format = 'JPEG'
    bild.save()
    bpy.data.images.remove(bild)
    with open(jpg, 'rb') as f2:
        daten = 'data:image/jpeg;base64,' + base64.b64encode(f2.read()).decode()
    return daten, w, h


class AMPHION_OT_ai_render(bpy.types.Operator):
    bl_idname = 'amphion.ai_render'
    bl_label = 'AI render'
    bl_description = ('Turn your render or camera view into a photorealistic image with Amphion AI. '
                      'Keeps your geometry and camera. Free images included, then 0,25 € each')

    _timer = None
    _faden = None
    _ergebnis = None

    def execute(self, context):
        if not online():
            self.report({'ERROR'}, 'Online access is off. Turn it on in Preferences > System > Network to use AI render.')
            return {'CANCELLED'}
        bild, w, h = _eingabebild(context)
        if not bild:
            self.report({'ERROR'}, 'Import a model first')
            return {'CANCELLED'}
        st = context.scene.amphion
        body = {'werkzeug': 'render', 'imagen': bild, 'ancho': w, 'alto': h, 'calidad': st.ki_qualitaet, 'opciones': {'texto': st.ki_text.strip()}}
        werte = _werte()
        erg = self._ergebnis = {}

        def lauf():
            try:
                erg['antwort'] = post('/v1/tools/generar', body, zeit=240.0, p=werte)
            except CloudFehler as e:
                erg['fehler'] = e.code
            except NetzFehler:
                erg['fehler'] = 'netz'
        self._faden = threading.Thread(target=lauf, daemon=True)
        self._faden.start()
        if bpy.app.background:
            self._faden.join()
            return self._abschluss(context)
        stand['meldung'] = 'AI render running … (about 20 seconds)'
        self._timer = context.window_manager.event_timer_add(0.5, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type != 'TIMER' or self._faden.is_alive():
            return {'PASS_THROUGH'}
        context.window_manager.event_timer_remove(self._timer)
        stand['meldung'] = ''
        return self._abschluss(context)

    def _abschluss(self, context):
        erg = self._ergebnis
        if 'fehler' in erg:
            code = erg['fehler']
            if code in ('gratis', 'saldo', 'pagar'):
                if not bpy.app.background:
                    bpy.ops.amphion.buy_credit('INVOKE_DEFAULT')
            self.report({'ERROR'}, FEHLERTEXT.get(code, 'No connection to Amphion. Check your internet and try again.' if code == 'netz' else 'AI render failed (' + code + ')'))
            return {'CANCELLED'}
        r = erg['antwort']
        url = r.get('imagen') or ''
        komma = url.find(',')
        daten = base64.b64decode(url[komma + 1:] if komma > 0 else url)
        pfad = os.path.join(bilder_ordner(), 'Amphion_AI_%s.%s' % (time.strftime('%Y%m%d_%H%M%S'), 'png' if 'image/png' in url[:30] else 'jpg'))
        with open(pfad, 'wb') as f:
            f.write(daten)
        stand['saldo'] = r.get('saldo')
        stand['ki_gratis'] = r.get('gratis')
        try:
            bpy.data.images.load(pfad, check_existing=True)
        except RuntimeError:
            pass
        oeffnen(pfad)
        self.report({'INFO'}, 'AI render saved: ' + pfad)
        return {'FINISHED'}


PAKETE = [('p5', '5 €', '5 € credit (20 AI images)'), ('p15', '15 € (+1,50 € bonus)', '16,50 € credit'), ('p40', '40 € (+6 € bonus)', '46 € credit')]


class AMPHION_OT_buy_credit(bpy.types.Operator):
    bl_idname = 'amphion.buy_credit'
    bl_label = 'Buy credit'
    bl_description = 'Credit for AI renders (0,25 € per image). Paid securely with Stripe in your browser, never expires'
    paket: EnumProperty(name='Pack', items=PAKETE, default='p15')

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        lay = self.layout
        lay.label(text='AI renders cost 0,25 € (High: 0,90 €). Credit never expires.')
        lay.prop(self, 'paket', expand=True)

    def execute(self, context):
        try:
            r = post('/v1/tools/comprar', {'paquete': self.paket, 'lang': 'en'}, zeit=12.0)
        except CloudFehler as e:
            self.report({'ERROR'}, 'Buying is not available right now, please try later.' if e.code == 'pronto' else 'Checkout failed (' + e.code + ')')
            return {'CANCELLED'}
        except NetzFehler:
            self.report({'ERROR'}, 'No connection to Amphion.')
            return {'CANCELLED'}
        p = einstellungen()
        if r.get('token') and p is not None:
            p.token = r['token']
            try:
                bpy.ops.wm.save_userpref()
            except Exception:
                pass
        if r.get('url'):
            webbrowser.open(r['url'])
        self.report({'INFO'}, 'Checkout opened in your browser. Your credit key is saved in the add-on preferences.')
        return {'FINISHED'}


class AMPHION_OT_subscribe(bpy.types.Operator):
    bl_idname = 'amphion.subscribe'
    bl_label = 'Subscribe'
    bl_description = 'Unlimited renders and exports for 4 € a month (or 40 € a year). Cancel any time'
    periode: EnumProperty(name='Billing', items=[('monat', 'Monthly · 4 €', ''), ('jahr', 'Yearly · 40 €', '')], default='monat')

    def execute(self, context):
        try:
            r = post('/v1/plugin/abo', {'produkt': PRODUKT, 'periode': self.periode, 'lang': 'en'}, zeit=12.0)
        except CloudFehler as e:
            self.report({'ERROR'}, 'Subscriptions open soon. Please try again later.' if e.code == 'pronto' else 'Checkout failed (' + e.code + ')')
            return {'CANCELLED'}
        except NetzFehler:
            self.report({'ERROR'}, 'No connection to Amphion.')
            return {'CANCELLED'}
        webbrowser.open(r.get('url') or 'https://amphion3d.com/blender/#pricing')
        self.report({'INFO'}, 'Checkout opened in your browser. Come back here after paying.')
        bpy.app.timers.register(lambda: (info_laden(), None)[1], first_interval=20.0)
        return {'FINISHED'}


class AMPHION_OT_subscribe_dialog(bpy.types.Operator):
    bl_idname = 'amphion.subscribe_dialog'
    bl_label = 'Amphion for Blender'
    bl_description = 'Your free renders are used'
    periode: EnumProperty(name='Billing', items=[('monat', 'Monthly · 4 € / month', ''), ('jahr', 'Yearly · 40 € / year (2 months free)', '')],
                          default='monat')

    def invoke(self, context, event):
        wm = context.window_manager
        try:
            return wm.invoke_props_dialog(self, width=420, confirm_text='Subscribe')
        except TypeError:   # vor 4.1 ohne confirm_text
            return wm.invoke_props_dialog(self, width=420)

    def draw(self, context):
        lay = self.layout
        lay.label(text='You have used your 10 free renders and exports.', icon='INFO')
        lay.label(text='Subscribe for unlimited renders, 3D print exports and updates.')
        lay.prop(self, 'periode', expand=True)
        lay.label(text='Cancel any time. Secure checkout with Stripe in your browser.')

    def execute(self, context):
        return bpy.ops.amphion.subscribe(periode=self.periode)


class AMPHION_OT_account(bpy.types.Operator):
    bl_idname = 'amphion.account'
    bl_label = 'Manage subscription'
    bl_description = 'Invoices and cancellation (Stripe customer portal)'

    def execute(self, context):
        try:
            r = post('/v1/plugin/portal', {'produkt': PRODUKT}, zeit=10.0)
            webbrowser.open(r['url'])
        except CloudFehler as e:
            self.report({'ERROR'}, 'No subscription on this computer yet.' if e.code == 'kein_abo' else 'Portal not available (' + e.code + ')')
            return {'CANCELLED'}
        except NetzFehler:
            self.report({'ERROR'}, 'No connection to Amphion.')
            return {'CANCELLED'}
        return {'FINISHED'}


class AMPHION_OT_refresh(bpy.types.Operator):
    bl_idname = 'amphion.refresh_account'
    bl_label = 'Refresh'
    bl_description = 'Check subscription, free renders and credit'

    def execute(self, context):
        info_laden()
        return {'FINISHED'}
